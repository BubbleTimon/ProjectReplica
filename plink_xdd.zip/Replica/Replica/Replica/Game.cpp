#include "pch.h"
#include "Game.h"

Game::Game()
{

}

Game::~Game()
{

}

void Game::Init(HWND hwnd)
{

}

void Game::Update()
{

}

void Game::Render()
{

}
