#pragma once
#include "Types.h"

const int32 GWinSizeX = 800;
const int32 GWinSizeY = 600;